#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <color.h>
#define SPEED 500000
int main(){
reset();
printf("\n");

  int i=0;
  for(i=0;i<100;i++){
    if(i%3==0){
        red();
	printf("\n");
    }else if(i%3==1){
	yellow();
	printf("\n");
    }else{
	reset();
	printf("\n");
    }	
    system("clear");
    usleep(SPEED);
    system("figlet _________    _________");
    usleep(SPEED);
    system("clear");
    system("figlet ________P   ________A");
    usleep(SPEED);
    system("clear");
    system("figlet _______PH   _______AN");
    usleep(SPEED);
    system("clear");
    system("figlet ______PHA   ______ANI");
    usleep(SPEED);
    system("clear");
    system("figlet _____PHAR   _____ANIM");
    usleep(SPEED);
    system("clear");
    system("figlet ____PHARM   ____ANIMA");
    usleep(SPEED);
    system("clear");
    system("figlet ___PHARMA   ___ANIMAT");
    usleep(SPEED);
    system("clear");
    system("figlet __PHARMAC    __ANIMATI");
    usleep(SPEED);
    system("clear");
   system("figlet _PHARMACI    _ANIMATIO");
    usleep(SPEED);
    system("clear");
    system("figlet PHARMACIE    ANIMATION");
    usleep(SPEED);
    system("clear");



  }
reset();

}
